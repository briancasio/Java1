import java.util.Scanner;
import java.io.IOException;
import java.io.File;

public class FingerPrint{


        
}
